#!/usr/bin/env python3
# bot_pg_queue.py
# -*- coding: utf-8 -*-
"""
Telegram YouTube Downloader Bot (Postgres + Queue/Workers)

Добавлено по сравнению с bot_pg.py:
- "правильная" очередь задач в Postgres (таблица jobs)
- воркеры (WORKERS=4 по умолчанию), которые берут задачи из asyncio.Queue
- ограничение параллелизма: ровно WORKERS задач одновременно
- пользователю показывается "В очереди: N" после выбора качества
- прогресс скачивания (yt-dlp progress_hooks) обновляет сообщение (с троттлингом)
- при рестарте бота: задачи со статусом queued/running возвращаются в очередь

Хранилище:
- settings (whitelist_enabled, cache_ttl_days)
- users (для broadcast, whitelist)
- video_cache (url+fmt -> file_id)
- jobs (очередь)
- downloads (лог)

Требования:
- Postgres + DATABASE_URL
- asyncpg
"""

import os
import logging
import tempfile
import subprocess
import json
import asyncio
import time
import re
from datetime import datetime
from dotenv import load_dotenv
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import (
    ApplicationBuilder,
    CommandHandler,
    MessageHandler,
    CallbackQueryHandler,
    ContextTypes,
    filters
)
from telegram.request import HTTPXRequest
import yt_dlp
import requests
from colorama import init, Fore, Style
import asyncpg

init(autoreset=True)

load_dotenv()
BOT_TOKEN = os.getenv("BOT_TOKEN")
API_BASE_URL = os.getenv("API_BASE_URL", "http://127.0.0.1:8443/bot")
ADMIN_ID = int(os.getenv("ADMIN_ID", "0"))

DATABASE_URL = os.getenv("DATABASE_URL")
CACHE_TTL_DAYS = int(os.getenv("CACHE_TTL_DAYS", "30"))
JOBS_TTL_DAYS = int(os.getenv("JOBS_TTL_DAYS", "7"))
FAILED_TTL_DAYS = int(os.getenv("FAILED_TTL_DAYS", "30"))

# Queue / workers
WORKERS = int(os.getenv("WORKERS", "4"))
MAX_QUEUE_PER_USER = int(os.getenv("MAX_QUEUE_PER_USER", "3"))
COOLDOWN_SECONDS = int(os.getenv("COOLDOWN_SECONDS", "5"))

# Channel subscription gate (optional)
REQUIRED_CHANNEL = os.getenv("REQUIRED_CHANNEL", "").strip()  # e.g. @mychannel or -100...
REQUIRED_CHANNEL_LINK = os.getenv("REQUIRED_CHANNEL_LINK", "").strip()

if not BOT_TOKEN:
    raise RuntimeError("BOT_TOKEN не найден в .env")
if not DATABASE_URL:
    raise RuntimeError("DATABASE_URL не найден в .env (нужен для Postgres-версии)")

logging.basicConfig(
    format="%(asctime)s — %(levelname)s — %(message)s",
    level=logging.INFO
)
logger = logging.getLogger(__name__)

tmp_dir = tempfile.mkdtemp(prefix="ytbot_")

DB_POOL: asyncpg.Pool | None = None
WORK_AVAILABLE: asyncio.Event = asyncio.Event()
SHUTDOWN_EVENT: asyncio.Event = asyncio.Event()
RUNNING_JOBS: set[int] = set()
USER_COOLDOWN: dict[int, float] = {}
CANCEL_EVENTS: dict[int, asyncio.Event] = {}
ADMIN_SESSIONS: dict[int, dict] = {}

SCHEMA_SQL = """
create table if not exists settings (
  key text primary key,
  value text not null
);

create table if not exists users (
  user_id bigint primary key,
  is_whitelisted boolean not null default false,
  first_seen timestamptz not null default now(),
  last_seen  timestamptz not null default now()
);

create table if not exists video_cache (
  id bigserial primary key,
  url text not null,
  fmt text not null,
  file_id text not null,
  title text,
  uploader text,
  duration int,
  resolution text,
  created_at timestamptz not null default now(),
  last_used  timestamptz not null default now(),
  unique(url, fmt)
);
create index if not exists video_cache_last_used_idx on video_cache(last_used);

create table if not exists jobs (
  id bigserial primary key,
  user_id bigint not null references users(user_id),
  chat_id bigint not null,
  reply_to_message_id int,
  progress_message_id int,       -- сообщение, которое будем редактировать прогрессом
  progress_has_photo boolean not null default false,
  url text not null,
  fmt text not null,
  label text not null,            -- например "720" или "auto"
  priority int not null default 0,  -- higher runs first
  duration int not null default 0,
  title text,
  uploader text,
  pub_date text,
  duration_str text,
  bot_link text,
  status text not null default 'queued', -- queued|running|done|failed|canceled
  cancel_requested boolean not null default false,
  error text,
  created_at timestamptz not null default now(),
  started_at timestamptz,
  finished_at timestamptz
);
create index if not exists jobs_status_idx on jobs(status);
create index if not exists jobs_user_status_idx on jobs(user_id, status);

alter table jobs add column if not exists cancel_requested boolean not null default false;
alter table jobs add column if not exists priority int not null default 0;

create table if not exists downloads (
  id bigserial primary key,
  user_id bigint not null references users(user_id),
  url text not null,
  fmt text not null,
  created_at timestamptz not null default now(),
  status text not null default 'done'  -- done|failed
);
"""

# ---------------
# DB helpers
# ---------------
async def init_db():
    global DB_POOL
    DB_POOL = await asyncpg.create_pool(DATABASE_URL, min_size=1, max_size=10)
    async with DB_POOL.acquire() as con:
        await con.execute(SCHEMA_SQL)
        await con.execute("""
            insert into settings(key, value) values('whitelist_enabled', 'false')
            on conflict (key) do nothing
        """)
        await con.execute("""
            insert into settings(key, value) values('cache_ttl_days', $1)
            on conflict (key) do update set value=excluded.value
        """, str(CACHE_TTL_DAYS))


async def get_setting(key: str, default: str) -> str:
    async with DB_POOL.acquire() as con:
        row = await con.fetchrow("select value from settings where key=$1", key)
        return (row["value"] if row else default)


async def set_setting(key: str, value: str):
    async with DB_POOL.acquire() as con:
        await con.execute(
            "insert into settings(key, value) values($1,$2) on conflict (key) do update set value=excluded.value",
            key, value
        )


async def whitelist_is_enabled() -> bool:
    return (await get_setting("whitelist_enabled", "false")).lower() == "true"


async def whitelist_set_enabled(enabled: bool):
    await set_setting("whitelist_enabled", "true" if enabled else "false")


async def ensure_user(user_id: int):
    async with DB_POOL.acquire() as con:
        await con.execute("""
            insert into users(user_id) values($1)
            on conflict (user_id) do update set last_seen=now()
        """, int(user_id))


async def set_user_whitelist(user_id: int, enabled: bool):
    async with DB_POOL.acquire() as con:
        await con.execute("""
            insert into users(user_id, is_whitelisted) values($1,$2)
            on conflict (user_id) do update set is_whitelisted=$2, last_seen=now()
        """, int(user_id), bool(enabled))


async def is_user_whitelisted(user_id: int) -> bool:
    async with DB_POOL.acquire() as con:
        row = await con.fetchrow("select is_whitelisted from users where user_id=$1", int(user_id))
        return bool(row and row["is_whitelisted"])


async def list_whitelist(limit: int = 200) -> list[int]:
    async with DB_POOL.acquire() as con:
        rows = await con.fetch("select user_id from users where is_whitelisted=true order by user_id limit $1", limit)
        return [int(r["user_id"]) for r in rows]


async def count_whitelist() -> int:
    async with DB_POOL.acquire() as con:
        return int(await con.fetchval("select count(*) from users where is_whitelisted=true"))


async def cache_get_file_id(url: str, fmt: str) -> str | None:
    async with DB_POOL.acquire() as con:
        row = await con.fetchrow("select file_id from video_cache where url=$1 and fmt=$2", url, fmt)
        if not row:
            return None
        await con.execute("update video_cache set last_used=now() where url=$1 and fmt=$2", url, fmt)
        return row["file_id"]


async def cache_get_meta(url: str, fmt: str) -> dict | None:
    """Return cached metadata for a given (url, fmt)."""
    async with DB_POOL.acquire() as con:
        row = await con.fetchrow(
            "select file_id, title, uploader, duration, resolution from video_cache where url=$1 and fmt=$2",
            url, fmt
        )
        if not row:
            return None
        await con.execute("update video_cache set last_used=now() where url=$1 and fmt=$2", url, fmt)
        return dict(row)


async def cache_get_fmts(url: str) -> set[str]:
    """Return set of format ids cached for this url."""
    async with DB_POOL.acquire() as con:
        rows = await con.fetch("select fmt from video_cache where url=$1", url)
        return {r["fmt"] for r in rows}


async def cache_upsert(url: str, fmt: str, file_id: str, *, title: str | None, uploader: str | None,
                       duration: int | None, resolution: str | None):
    async with DB_POOL.acquire() as con:
        await con.execute("""
            insert into video_cache(url, fmt, file_id, title, uploader, duration, resolution, last_used)
            values($1,$2,$3,$4,$5,$6,$7,now())
            on conflict (url, fmt) do update set
              file_id=excluded.file_id,
              title=excluded.title,
              uploader=excluded.uploader,
              duration=excluded.duration,
              resolution=excluded.resolution,
              last_used=now()
        """, url, fmt, file_id, title, uploader, duration, resolution)


async def cache_cleanup_loop():
    while True:
        try:
            ttl_days = int((await get_setting("cache_ttl_days", str(CACHE_TTL_DAYS))) or str(CACHE_TTL_DAYS))
            async with DB_POOL.acquire() as con:
                await con.execute(
                    "delete from video_cache where last_used < now() - ($1::int * interval '1 day')",
                    ttl_days
                )
        except Exception:
            logger.exception("cache cleanup failed")
        await asyncio.sleep(6 * 60 * 60)


async def queue_position(job_id: int) -> tuple[int, int, int]:
    """Returns (position_in_queued, total_queued, running_count).
    Position counts only queued jobs ordered by id.
    If job is not queued, position may be 0.
    """
    async with DB_POOL.acquire() as con:
        status = await con.fetchval("select status from jobs where id=$1", int(job_id))
        total_queued = int(await con.fetchval("select count(*) from jobs where status='queued'"))
        running_count = int(await con.fetchval("select count(*) from jobs where status='running'"))
        if status != 'queued':
            return (0, total_queued, running_count)
        prio = int(await con.fetchval("select priority from jobs where id=$1", int(job_id)) or 0)
        ahead = int(await con.fetchval(
            """select count(*) from jobs
                 where status='queued'
                   and (priority > $1 or (priority = $1 and id < $2))""",
            prio, int(job_id)
        ))
        return (ahead + 1, total_queued, running_count)
async def user_job_position(job_id: int, user_id: int) -> tuple[int, int]:
    """Returns (position_among_user_active, total_user_active).
    Ordering:
      1) running first (by started_at/id)
      2) queued next (by priority desc, id asc)
    """
    async with DB_POOL.acquire() as con:
        row = await con.fetchrow("select status, priority, started_at from jobs where id=$1", int(job_id))
        total = int(await con.fetchval(
            "select count(*) from jobs where user_id=$1 and status in ('queued','running')",
            int(user_id)
        ))
        if not row or row["status"] not in ('queued','running'):
            return (0, total)

        status = row["status"]
        prio = int(row.get("priority") or 0)

        running_ahead = int(await con.fetchval(
            """select count(*) from jobs
                 where user_id=$1 and status='running'
                   and id < $2""",  # deterministic
            int(user_id), int(job_id)
        ))
        running_total = int(await con.fetchval(
            "select count(*) from jobs where user_id=$1 and status='running'",
            int(user_id)
        ))

        if status == 'running':
            return (running_ahead + 1, total)

        # queued: position is after all running + queued ahead by priority/id
        queued_ahead = int(await con.fetchval(
            """select count(*) from jobs
                 where user_id=$1 and status='queued'
                   and (priority > $2 or (priority = $2 and id < $3))""",
            int(user_id), prio, int(job_id)
        ))
        return (running_total + queued_ahead + 1, total)


async def jobs_cleanup_loop():
    """Delete old terminal jobs:
    - done/canceled older than JOBS_TTL_DAYS
    - failed older than FAILED_TTL_DAYS (keep longer for diagnostics)
    """
    while True:
        try:
            async with DB_POOL.acquire() as con:
                # done/canceled
                await con.execute(
                    """delete from jobs
                         where status in ('done','canceled')
                           and finished_at is not null
                           and finished_at < now() - ($1::int * interval '1 day')""",
                    int(JOBS_TTL_DAYS)
                )
                # failed (kept longer)
                await con.execute(
                    """delete from jobs
                         where status = 'failed'
                           and finished_at is not null
                           and finished_at < now() - ($1::int * interval '1 day')""",
                    int(FAILED_TTL_DAYS)
                )
        except Exception:
            logger.exception("jobs cleanup failed")
        await asyncio.sleep(6 * 60 * 60)




async def user_active_jobs_count(user_id: int) -> int:
    async with DB_POOL.acquire() as con:
        return int(await con.fetchval(
            "select count(*) from jobs where user_id=$1 and status in ('queued','running')",
            int(user_id)
        ))


async def create_job(*, user_id: int, chat_id: int, reply_to_message_id: int | None,
                     progress_message_id: int | None, progress_has_photo: bool,
                     url: str, fmt: str, label: str, duration: int,
                     video_info: dict, priority: int = 0) -> int:
    async with DB_POOL.acquire() as con:
        job_id = await con.fetchval("""
            insert into jobs(
              user_id, chat_id, reply_to_message_id,
              progress_message_id, progress_has_photo,
              url, fmt, label, duration,
              title, uploader, pub_date, duration_str, bot_link,
              status, priority
            )
            values($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,'queued',$15)
            returning id
        """,
        int(user_id), int(chat_id), reply_to_message_id,
        progress_message_id, bool(progress_has_photo),
        url, fmt, label, int(duration),
        video_info.get('title'), video_info.get('uploader'),
        video_info.get('pub_date'), video_info.get('duration_str'),
        video_info.get('bot_link'), int(priority))
        return int(job_id)


async def fetch_job(job_id: int) -> dict | None:
    async with DB_POOL.acquire() as con:
        row = await con.fetchrow("select * from jobs where id=$1", int(job_id))
        return dict(row) if row else None

async def claim_next_job() -> dict | None:
    """Atomically pick the next queued job by (priority desc, id asc), mark running, return row.
    Uses SKIP LOCKED so multiple workers can claim concurrently.
    """
    async with DB_POOL.acquire() as con:
        async with con.transaction():
            row = await con.fetchrow(
                """select * from jobs
                     where status='queued' and cancel_requested=false
                     order by priority desc, id asc
                     limit 1
                     for update skip locked"""
            )
            if not row:
                return None
            await con.execute(
                "update jobs set status='running', started_at=now() where id=$1",
                int(row["id"])
            )
            return dict(row)


async def mark_job_running(job_id: int):
    async with DB_POOL.acquire() as con:
        await con.execute("update jobs set status='running', started_at=now() where id=$1", int(job_id))


async def mark_job_done(job_id: int):
    async with DB_POOL.acquire() as con:
        await con.execute("update jobs set status='done', finished_at=now() where id=$1", int(job_id))


async def mark_job_canceled(job_id: int):
    async with DB_POOL.acquire() as con:
        await con.execute("update jobs set status='canceled', finished_at=now() where id=$1", int(job_id))


async def mark_job_failed(job_id: int, error: str):
    async with DB_POOL.acquire() as con:
        await con.execute("update jobs set status='failed', error=$2, finished_at=now() where id=$1", int(job_id), error[:4000])


async def requeue_incomplete_jobs():
    """On startup: reset running -> queued after restart."""
    async with DB_POOL.acquire() as con:
        await con.execute("update jobs set status='queued' where status='running'")



# ---------------
# Access control
# ---------------
async def is_user_subscribed_to_required_channel(context: ContextTypes.DEFAULT_TYPE, user_id: int) -> bool:
    if not REQUIRED_CHANNEL:
        return False
    try:
        member = await context.bot.get_chat_member(chat_id=REQUIRED_CHANNEL, user_id=user_id)
        return member.status in ("creator", "administrator", "member")
    except Exception:
        logger.exception("Не удалось проверить подписку на канал")
        return False


async def ensure_access_or_prompt(update: Update, context: ContextTypes.DEFAULT_TYPE) -> bool:
    uid = update.effective_user.id
    if not await whitelist_is_enabled():
        return True
    if await is_user_whitelisted(uid):
        return True
    if await is_user_subscribed_to_required_channel(context, uid):
        return True

    link = REQUIRED_CHANNEL_LINK or (f"https://t.me/{REQUIRED_CHANNEL.lstrip('@')}" if REQUIRED_CHANNEL.startswith("@") else "")
    text = "⛔️ Сейчас включен whitelist.\n\n"
    if REQUIRED_CHANNEL:
        text += "✅ Чтобы пользоваться ботом без добавления в whitelist, подпишись на канал и нажми /check.\n"
    text += "\nЕсли ты владелец доступа — попроси админа добавить тебя в whitelist."
    buttons = []
    if link:
        buttons.append([InlineKeyboardButton("📢 Подписаться на канал", url=link)])
    buttons.append([InlineKeyboardButton("🔄 Проверить доступ", callback_data="check_access")])
    try:
        await update.message.reply_text(text, reply_markup=InlineKeyboardMarkup(buttons))
    except Exception:
        try:
            await context.bot.send_message(chat_id=update.effective_chat.id, text=text, reply_markup=InlineKeyboardMarkup(buttons))
        except Exception:
            pass
    return False


# ---------------
# Utilities
# ---------------
def get_video_dimensions(path: str) -> tuple[int, int]:
    result = subprocess.check_output([
        'ffprobe', '-v', 'error',
        '-select_streams', 'v:0',
        '-show_entries', 'stream=width,height',
        '-of', 'json', path
    ])
    info = json.loads(result)
    stream = info.get('streams', [{}])[0]
    return (int(stream.get('width', 0)), int(stream.get('height', 0)))



def normalize_youtube_url(url: str) -> str:
    u = (url or "").strip()
    m = re.search(r"(?:youtube\.com)/(?:shorts)/([a-zA-Z0-9_-]{6,})", u)
    if m:
        vid = m.group(1)
        return f"https://www.youtube.com/watch?v={vid}"
    return u

def build_caption(info: dict, resolution: str) -> str:
    return (
        f"🎬 <b>Название:</b> {info.get('title','N/A')}\n"
        f"👤 <b>Автор:</b> {info.get('uploader','N/A')}\n"
        f"📅 <b>Дата:</b> {info.get('pub_date','N/A')}\n"
        f"⏱ <b>Длительность:</b> {info.get('duration_str','00:00:00')}\n"
        f"📐 <b>Разрешение:</b> {resolution}\n\n"
        f"🔗 <b>Бот:</b> {info.get('bot_link','')}"
    )


def make_progress_hook(loop, app, chat_id: int, message_id: int, has_photo: bool, label: str):
    last = {"t": 0.0}

    def hook(d):
        try:
            if d.get("status") != "downloading":
                return
            now = time.time()
            if now - last["t"] < 1.0:
                return
            last["t"] = now

            total = d.get("total_bytes") or d.get("total_bytes_estimate") or 0
            downloaded = d.get("downloaded_bytes") or 0
            eta = d.get("eta") or 0

            pct = (downloaded / total * 100.0) if total else 0.0
            text = f"⏬ Скачиваю {label}… {pct:.1f}% | ETA: {eta}s"

            async def _edit():
                try:
                    if has_photo:
                        await app.bot.edit_message_caption(chat_id=chat_id, message_id=message_id, caption=text)
                    else:
                        await app.bot.edit_message_text(chat_id=chat_id, message_id=message_id, text=text)
                except Exception:
                    pass

            asyncio.run_coroutine_threadsafe(_edit(), loop)
        except Exception:
            pass

    return hook


# ---------------
# Commands
# ---------------
async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    uid = update.effective_user.id
    await ensure_user(uid)
    if not await ensure_access_or_prompt(update, context):
        return
    await update.message.reply_text("👋 Привет! Пришли ссылку на YouTube.")


async def check(update: Update, context: ContextTypes.DEFAULT_TYPE):
    uid = update.effective_user.id
    await ensure_user(uid)
    if await ensure_access_or_prompt(update, context):
        await update.message.reply_text("✅ Доступ подтверждён. Можешь отправлять ссылку на YouTube.")


# -------------------------
# Admin UI (inline buttons)
# -------------------------
def _is_admin(uid: int) -> bool:
    return uid == ADMIN_ID

def admin_main_kb():
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("📥 Очередь", callback_data="admin:queue")],
        [InlineKeyboardButton("🔒 Whitelist", callback_data="admin:whitelist")],
        [InlineKeyboardButton("🧹 Чистка", callback_data="admin:cleanup")],
        [InlineKeyboardButton("📣 Рассылка", callback_data="admin:broadcast")],
        [InlineKeyboardButton("⚙️ Статус", callback_data="admin:status")],
    ])

def admin_back_kb(section: str = "main"):
    return InlineKeyboardMarkup([[InlineKeyboardButton("⬅️ Назад", callback_data=f"admin:back:{section}")]])

async def admin(update: Update, context: ContextTypes.DEFAULT_TYPE):
    uid = update.effective_user.id
    if not _is_admin(uid):
        return await update.message.reply_text("❌ У вас нет прав.")
    ADMIN_SESSIONS.pop(uid, None)
    await update.message.reply_text("🛠 <b>Панель администратора</b>", parse_mode="HTML", reply_markup=admin_main_kb())

async def admin_render_queue(message, context: ContextTypes.DEFAULT_TYPE, page: int = 0):
    """Render queue page with inline actions per job."""
    page_size = 10
    page = max(0, int(page))
    offset = page * page_size

    async with DB_POOL.acquire() as con:
        total = int(await con.fetchval("select count(*) from jobs where status in ('queued','running')"))
        queued = int(await con.fetchval("select count(*) from jobs where status='queued'"))
        running = int(await con.fetchval("select count(*) from jobs where status='running'"))

        rows = await con.fetch(
            """select id, user_id, status, label, url, priority
                 from jobs
                 where status in ('queued','running')
                 order by
                   case when status='running' then 0 else 1 end,
                   priority desc,
                   id
                 limit $1 offset $2""",
            page_size, offset
        )

    pages = max(1, (total + page_size - 1) // page_size)
    if page >= pages:
        page = pages - 1
        offset = page * page_size

    header = f"📥 <b>Очередь</b> — активных: <b>{total}</b> (queued: <b>{queued}</b>, running: <b>{running}</b>)\n"
    header += f"Страница: <b>{page+1}/{pages}</b>\n\n"

    if not rows:
        text = header + "Очередь пуста."
        kb = InlineKeyboardMarkup([
            [InlineKeyboardButton("🔄 Обновить", callback_data=f"admin:queue:page:{page}")],
            [InlineKeyboardButton("⬅️ Назад", callback_data="admin:back:main")],
        ])
        return await message.edit_text(text, parse_mode="HTML", reply_markup=kb)

    lines = [header]
    kb_rows = []

    # Controls row
    kb_rows.append([
        InlineKeyboardButton("🔄", callback_data=f"admin:queue:page:{page}"),
        InlineKeyboardButton("⬅️", callback_data=f"admin:queue:page:{max(0, page-1)}"),
        InlineKeyboardButton("➡️", callback_data=f"admin:queue:page:{min(pages-1, page+1)}"),
    ])

    # Render each job with action buttons
    for r in rows:
        jid = int(r["id"])
        uid = int(r["user_id"])
        st = r["status"]
        label = r["label"]
        pr = int(r.get("priority") or 0)
        url = (r["url"] or "")
        if len(url) > 55:
            url = url[:52] + "…"

        if st == "queued":
            pos, total_q, _ = await queue_position(jid)
            ptxt = f"#{pos}/{total_q}" if pos else "—"
        else:
            ptxt = "RUN"

        lines.append(f"<code>{jid}</code> | <b>{st.upper()}</b> | {ptxt} | pr:{pr} | u:{uid} | {label} | {url}")

        # Inline actions per job:
        # - bump available only for queued (we'll show button but handler will validate)
        # - cancel for queued/running
        kb_rows.append([
            InlineKeyboardButton(f"⬆️ {jid}", callback_data=f"admin:queue:bump:{jid}"),
            InlineKeyboardButton(f"🚫 {jid}", callback_data=f"admin:queue:cancel:{jid}"),
        ])

    # Footer navigation
    kb_rows.append([
        InlineKeyboardButton("⬅️ Назад", callback_data="admin:back:main"),
    ])

    return await message.edit_text("\n".join(lines), parse_mode="HTML", reply_markup=InlineKeyboardMarkup(kb_rows))


async def admin_render_whitelist(message, context: ContextTypes.DEFAULT_TYPE):
    enabled = await whitelist_is_enabled()
    cnt = await count_whitelist()
    text = (
        "🔒 <b>Whitelist</b>\n"
        f"Статус: <b>{'ON' if enabled else 'OFF'}</b>\n"
        f"Пользователей в whitelist: <b>{cnt}</b>\n"
        f"Канал для доступа: <b>{REQUIRED_CHANNEL or 'не задан'}</b>"
    )
    kb = InlineKeyboardMarkup([
        [InlineKeyboardButton("✅ Включить", callback_data="admin:whitelist:on"),
         InlineKeyboardButton("🚫 Выключить", callback_data="admin:whitelist:off")],
        [InlineKeyboardButton("➕ Добавить user_id", callback_data="admin:whitelist:ask_add"),
         InlineKeyboardButton("➖ Удалить user_id", callback_data="admin:whitelist:ask_del")],
        [InlineKeyboardButton("📄 Показать список", callback_data="admin:whitelist:list")],
        [InlineKeyboardButton("⬅️ Назад", callback_data="admin:back:main")],
    ])
    return await message.edit_text(text, parse_mode="HTML", reply_markup=kb)

async def admin_render_cleanup(message, context: ContextTypes.DEFAULT_TYPE):
    text = (
        "🧹 <b>Чистка</b>\n"
        f"done/canceled удаляем старше <b>{JOBS_TTL_DAYS}</b> дней\n"
        f"failed удаляем старше <b>{FAILED_TTL_DAYS}</b> дней"
    )
    kb = InlineKeyboardMarkup([
        [InlineKeyboardButton("🧹 Запустить сейчас", callback_data="admin:cleanup:run")],
        [InlineKeyboardButton("⬅️ Назад", callback_data="admin:back:main")],
    ])
    return await message.edit_text(text, parse_mode="HTML", reply_markup=kb)

async def admin_render_broadcast(message, context: ContextTypes.DEFAULT_TYPE):
    text = "📣 <b>Рассылка</b>\nНажми кнопку и отправь текст следующим сообщением."
    kb = InlineKeyboardMarkup([
        [InlineKeyboardButton("✍️ Ввести текст рассылки", callback_data="admin:broadcast:ask")],
        [InlineKeyboardButton("⬅️ Назад", callback_data="admin:back:main")],
    ])
    return await message.edit_text(text, parse_mode="HTML", reply_markup=kb)

async def admin_render_status(message, context: ContextTypes.DEFAULT_TYPE):
    async with DB_POOL.acquire() as con:
        users_total = await con.fetchval("select count(*) from users")
        cache_items = await con.fetchval("select count(*) from video_cache")
        done = await con.fetchval("select count(*) from jobs where status='done'")
        queued = await con.fetchval("select count(*) from jobs where status='queued'")
        running = await con.fetchval("select count(*) from jobs where status='running'")
        failed = await con.fetchval("select count(*) from jobs where status='failed'")
        canceled = await con.fetchval("select count(*) from jobs where status='canceled'")
    text = (
        "⚙️ <b>Статус</b>\n"
        f"WORKERS: <b>{WORKERS}</b>\n"
        f"Пользователей: <b>{users_total}</b>\n"
        f"Кэш: <b>{cache_items}</b>\n\n"
        f"Очередь: <b>{queued}</b> | В работе: <b>{running}</b>\n"
        f"Готово: <b>{done}</b> | Ошибок: <b>{failed}</b> | Отменено: <b>{canceled}</b>"
    )
    kb = InlineKeyboardMarkup([
        [InlineKeyboardButton("⬅️ Назад", callback_data="admin:back:main")],
    ])
    return await message.edit_text(text, parse_mode="HTML", reply_markup=kb)

async def admin_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    q = update.callback_query
    uid = q.from_user.id
    if not _is_admin(uid):
        await q.answer("Нет прав", show_alert=True)
        return
    data = q.data or ""
    await q.answer()

    # navigation
    # queue paging & per-job actions
    if data.startswith("admin:queue:page:"):
        try:
            page = int(data.split(":")[-1])
        except Exception:
            page = 0
        return await admin_render_queue(q.message, context, page=page)

    if data.startswith("admin:queue:bump:"):
        try:
            jid = int(data.split(":")[-1])
        except Exception:
            return
        async with DB_POOL.acquire() as con:
            row = await con.fetchrow("select status from jobs where id=$1", jid)
            if not row:
                return await q.message.reply_text("Задача не найдена.")
            if row["status"] != "queued":
                return await q.message.reply_text("Можно поднимать только задачи со статусом queued.")
            mx = int(await con.fetchval("select coalesce(max(priority),0) from jobs where status='queued'") or 0)
            await con.execute("update jobs set priority=$2 where id=$1", jid, mx + 1)
        WORK_AVAILABLE.set()
        await q.message.reply_text(f"✅ Задача {jid} поднята в начало очереди.")
        return await admin_render_queue(q.message, context, page=0)

    if data.startswith("admin:queue:cancel:"):
        try:
            jid = int(data.split(":")[-1])
        except Exception:
            return
        async with DB_POOL.acquire() as con:
            row = await con.fetchrow("select status from jobs where id=$1", jid)
            if not row:
                return await q.message.reply_text("Задача не найдена.")
            st = row["status"]
            if st == "queued":
                await con.execute(
                    "update jobs set status='canceled', cancel_requested=true, finished_at=now() where id=$1", jid
                )
            elif st == "running":
                await con.execute("update jobs set cancel_requested=true where id=$1", jid)
            else:
                return await q.message.reply_text(f"Задача уже {st}.")
        ev = CANCEL_EVENTS.get(jid)
        if ev:
            ev.set()
        await q.message.reply_text(f"✅ Отмена запрошена для {jid}.")
        return await admin_render_queue(q.message, context, page=0)





    # whitelist actions
    if data == "admin:whitelist:on":
        await whitelist_set_enabled(True)
        return await admin_render_whitelist(q.message, context)
    if data == "admin:whitelist:off":
        await whitelist_set_enabled(False)
        return await admin_render_whitelist(q.message, context)
    if data == "admin:whitelist:ask_add":
        ADMIN_SESSIONS[uid] = {"mode": "wl_add", "reply_to": q.message.message_id}
        return await q.message.reply_text("➕ Отправь user_id следующим сообщением.")
    if data == "admin:whitelist:ask_del":
        ADMIN_SESSIONS[uid] = {"mode": "wl_del", "reply_to": q.message.message_id}
        return await q.message.reply_text("➖ Отправь user_id следующим сообщением.")
    if data == "admin:whitelist:list":
        ids = await list_whitelist(limit=200)
        txt = "Whitelist пуст." if not ids else ("👥 <b>Whitelist</b>\n" + "\n".join(map(str, ids)))
        return await q.message.reply_text(txt, parse_mode="HTML")


    # cleanup
    if data == "admin:cleanup:run":
        d_done, d_failed = await run_jobs_cleanup_once()
        await q.message.reply_text(
            f"🧹 Очистка завершена.\n"
            f"Удалено done/canceled: {d_done} (>{JOBS_TTL_DAYS}d)\n"
            f"Удалено failed: {d_failed} (>{FAILED_TTL_DAYS}d)"
        )
        return await admin_render_cleanup(q.message, context)

    # broadcast
    if data == "admin:broadcast:ask":
        ADMIN_SESSIONS[uid] = {"mode": "broadcast", "reply_to": q.message.message_id}
        return await q.message.reply_text("📣 Отправь текст рассылки следующим сообщением.")

async def admin_input_router(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle admin inputs requested by admin panel buttons."""
    uid = update.effective_user.id
    if not _is_admin(uid):
        return
    sess = ADMIN_SESSIONS.get(uid)
    if not sess:
        return

    mode = sess.get("mode")
    text = (update.message.text or "").strip()

    try:
        if mode == "wl_add":
            user_id = int(text)
            await set_user_whitelist(user_id, True)
            ADMIN_SESSIONS.pop(uid, None)
            await update.message.reply_text(f"✅ Добавлен в whitelist: {user_id}")
            return
        if mode == "wl_del":
            user_id = int(text)
            await set_user_whitelist(user_id, False)
            ADMIN_SESSIONS.pop(uid, None)
            await update.message.reply_text(f"✅ Удалён из whitelist: {user_id}")
            return
        if mode == "bump":
            jid = int(text)
            # reuse bump logic without command
            async with DB_POOL.acquire() as con:
                row = await con.fetchrow("select status from jobs where id=$1", jid)
                if not row:
                    return await update.message.reply_text("Задача не найдена.")
                if row["status"] != "queued":
                    return await update.message.reply_text("Можно поднимать только queued.")
                mx = int(await con.fetchval("select coalesce(max(priority),0) from jobs where status='queued'") or 0)
                await con.execute("update jobs set priority=$2 where id=$1", jid, mx + 1)
            WORK_AVAILABLE.set()
            ADMIN_SESSIONS.pop(uid, None)
            await update.message.reply_text(f"✅ Задача {jid} поднята.")
            return
        if mode == "prio":
            parts = text.split()
            if len(parts) < 2:
                return await update.message.reply_text("Нужно: job_id priority (например: 123 50)")
            jid = int(parts[0]); p = int(parts[1])
            async with DB_POOL.acquire() as con:
                row = await con.fetchrow("select status from jobs where id=$1", jid)
                if not row:
                    return await update.message.reply_text("Задача не найдена.")
                if row["status"] != "queued":
                    return await update.message.reply_text("Менять приоритет можно только для queued.")
                await con.execute("update jobs set priority=$2 where id=$1", jid, p)
            WORK_AVAILABLE.set()
            ADMIN_SESSIONS.pop(uid, None)
            await update.message.reply_text(f"✅ Приоритет {jid} = {p}")
            return
        if mode == "cancel":
            jid = int(text)
            # cancel as admin
            async with DB_POOL.acquire() as con:
                row = await con.fetchrow("select status from jobs where id=$1", jid)
                if not row:
                    return await update.message.reply_text("Задача не найдена.")
                st = row["status"]
                if st == "queued":
                    await con.execute("update jobs set status='canceled', cancel_requested=true, finished_at=now() where id=$1", jid)
                elif st == "running":
                    await con.execute("update jobs set cancel_requested=true where id=$1", jid)
                else:
                    return await update.message.reply_text(f"Задача уже {st}.")
            ev = CANCEL_EVENTS.get(jid)
            if ev:
                ev.set()
            ADMIN_SESSIONS.pop(uid, None)
            await update.message.reply_text(f"✅ Отмена запрошена для {jid}.")
            return
        if mode == "broadcast":
            # reuse broadcast logic without command
            btext = text
            if not btext:
                return await update.message.reply_text("Текст пустой.")
            async with DB_POOL.acquire() as con:
                rows = await con.fetch("select user_id from users")
            sent, failed = 0, 0
            for r in rows:
                chat_id = int(r["user_id"])
                try:
                    await context.bot.send_message(chat_id, btext)
                    sent += 1
                except Exception:
                    failed += 1
            ADMIN_SESSIONS.pop(uid, None)
            await update.message.reply_text(f"✅ Рассылка завершена: успешно {sent}, неудачно {failed}.")
            return
    except ValueError:
        return await update.message.reply_text("❌ Неверный формат. Попробуй ещё раз.")
    except Exception:
        logger.exception("admin_input_router error")
        return await update.message.reply_text("❌ Ошибка выполнения. Смотри логи.")

async def wl_on(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.effective_user.id != ADMIN_ID:
        return await update.message.reply_text("❌ У вас нет прав.")
    await whitelist_set_enabled(True)
    await update.message.reply_text("✅ Whitelist включен.")


async def wl_off(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.effective_user.id != ADMIN_ID:
        return await update.message.reply_text("❌ У вас нет прав.")
    await whitelist_set_enabled(False)
    await update.message.reply_text("✅ Whitelist выключен.")


async def wl_status(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.effective_user.id != ADMIN_ID:
        return await update.message.reply_text("❌ У вас нет прав.")
    enabled = "ON" if await whitelist_is_enabled() else "OFF"
    count = await count_whitelist()
    await update.message.reply_text(
        f"🔒 Whitelist: <b>{enabled}</b>\n"
        f"👥 В whitelist: <b>{count}</b>\n"
        f"📢 Канал для доступа: <b>{REQUIRED_CHANNEL or 'не задан'}</b>",
        parse_mode="HTML"
    )


async def wl_add(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.effective_user.id != ADMIN_ID:
        return await update.message.reply_text("❌ У вас нет прав.")
    if not context.args:
        return await update.message.reply_text("Использование: /wl_add <user_id>")
    try:
        user_id = int(context.args[0])
    except ValueError:
        return await update.message.reply_text("❌ user_id должен быть числом.")
    await set_user_whitelist(user_id, True)
    await update.message.reply_text(f"✅ Добавлен в whitelist: {user_id}")


async def wl_del(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.effective_user.id != ADMIN_ID:
        return await update.message.reply_text("❌ У вас нет прав.")
    if not context.args:
        return await update.message.reply_text("Использование: /wl_del <user_id>")
    try:
        user_id = int(context.args[0])
    except ValueError:
        return await update.message.reply_text("❌ user_id должен быть числом.")
    await set_user_whitelist(user_id, False)
    await update.message.reply_text(f"✅ Удалён из whitelist: {user_id}")


async def wl_list(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.effective_user.id != ADMIN_ID:
        return await update.message.reply_text("❌ У вас нет прав.")
    ids = await list_whitelist(limit=200)
    if not ids:
        return await update.message.reply_text("Whitelist пуст.")
    await update.message.reply_text("👥 <b>Whitelist users</b>\n" + "\n".join(map(str, ids)), parse_mode="HTML")


async def broadcast(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.effective_user.id != ADMIN_ID:
        return await update.message.reply_text("❌ У вас нет прав для рассылки.")
    text = ' '.join(context.args)
    if not text:
        return await update.message.reply_text("Использование: /broadcast <текст>")
    async with DB_POOL.acquire() as con:
        rows = await con.fetch("select user_id from users")
    sent, failed = 0, 0
    for r in rows:
        chat_id = int(r["user_id"])
        try:
            await context.bot.send_message(chat_id, text)
            sent += 1
        except Exception:
            failed += 1
    await update.message.reply_text(f"✅ Рассылка завершена: успешно {sent}, неудачно {failed}.")


async def stats(update: Update, context: ContextTypes.DEFAULT_TYPE):
    uid = update.effective_user.id
    await ensure_user(uid)
    async with DB_POOL.acquire() as con:
        users_total = await con.fetchval("select count(*) from users")
        users_wh = await con.fetchval("select count(*) from users where is_whitelisted=true")
        cache_items = await con.fetchval("select count(*) from video_cache")
        done = await con.fetchval("select count(*) from jobs where status='done'")
        queued = await con.fetchval("select count(*) from jobs where status='queued'")
        running = await con.fetchval("select count(*) from jobs where status='running'")
        failed = await con.fetchval("select count(*) from jobs where status='failed'")
        canceled = await con.fetchval("select count(*) from jobs where status='canceled'")
    await update.message.reply_text(
        "📊 <b>Статистика</b>\n"
        f"👥 Пользователей: <b>{users_total}</b> (whitelist: <b>{users_wh}</b>)\n"
        f"🧠 Кэш записей: <b>{cache_items}</b>\n"
        f"📥 Очередь: <b>{queued}</b> | 🏃‍♂️ В работе: <b>{running}</b>\n"
        f"✅ Готово: <b>{done}</b> | ❌ Ошибок: <b>{failed}</b> | 🚫 Отменено: <b>{canceled}</b>",
        parse_mode="HTML"
    )


async def queue_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Admin: show active jobs (queued/running)."""
    if update.effective_user.id != ADMIN_ID:
        return await update.message.reply_text("❌ У вас нет прав.")
    limit = 20
    try:
        if context.args:
            limit = max(1, min(50, int(context.args[0])))
    except ValueError:
        pass
    async with DB_POOL.acquire() as con:
        rows = await con.fetch(
            """select id, user_id, status, label, url, created_at, started_at
                 from jobs
                 where status in ('queued','running')
                 order by
                   case when status='running' then 0 else 1 end,
                   priority desc,
                   id
                 limit $1""",
            limit
        )
        total = int(await con.fetchval("select count(*) from jobs where status in ('queued','running')"))
        queued = int(await con.fetchval("select count(*) from jobs where status='queued'"))
        running = int(await con.fetchval("select count(*) from jobs where status='running'"))

    if not rows:
        return await update.message.reply_text("Очередь пуста.")

    lines = [f"📥 Активных: {total} (queued: {queued}, running: {running})", ""]
    for r in rows:
        jid = int(r["id"])
        uid = int(r["user_id"])
        st = r["status"]
        label = r["label"]
        url = (r["url"] or "")
        if len(url) > 45:
            url = url[:42] + "…"
        if st == "queued":
            pos, total_q, _ = await queue_position(jid)
            pos_txt = f"#{pos}/{total_q}" if pos else "—"
        else:
            pos_txt = "RUN"
        lines.append(f"{jid} | {st.upper():7} | {pos_txt:8} | u:{uid} | {label} | {url}")

    await update.message.reply_text("\n".join(lines))


async def myqueue(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """User: show only their active jobs with cancel buttons."""
    uid = update.effective_user.id
    await ensure_user(uid)

    async with DB_POOL.acquire() as con:
        rows = await con.fetch(
            """select id, status, label, url, priority
                 from jobs
                 where user_id=$1 and status in ('queued','running')
                 order by
                   case when status='running' then 0 else 1 end,
                   priority desc,
                   id
                 limit 20""",
            int(uid)
        )
        total_user = int(await con.fetchval(
            "select count(*) from jobs where user_id=$1 and status in ('queued','running')",
            int(uid)
        ))
        total_q = int(await con.fetchval("select count(*) from jobs where status='queued'"))
        running = int(await con.fetchval("select count(*) from jobs where status='running'"))

    if not rows:
        return await update.message.reply_text("У тебя нет активных задач.")

    lines = [f"📥 Твои активные задачи: {total_user} (queued всего: {total_q}, в работе: {running})", ""]
    buttons = []
    for r in rows:
        jid = int(r["id"])
        st = r["status"]
        label = r["label"]
        url = (r["url"] or "")
        if len(url) > 45:
            url = url[:42] + "…"

        if st == "queued":
            gpos, gtotal, _ = await queue_position(jid)
            gtxt = f"#{gpos}/{gtotal}" if gpos else "—"
        else:
            gtxt = "RUN"
        upos, utotal = await user_job_position(jid, uid)
        utxt = f"#{upos}/{utotal}" if upos else "—"
        pr = int(r.get("priority") or 0)

        lines.append(f"{jid} | {st.upper():7} | global {gtxt:8} | you {utxt:8} | pr:{pr} | {label} | {url}")

        buttons.append(InlineKeyboardButton(f"❌ {jid}", callback_data=f"cancel_{jid}"))

    # arrange buttons 2 per row
    kb = [buttons[i:i+2] for i in range(0, len(buttons), 2)]
    await update.message.reply_text("\n".join(lines), reply_markup=InlineKeyboardMarkup(kb))

async def cancel(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """User: cancel a queued/running job. Usage: /cancel [job_id]
    If job_id omitted, cancels the newest active job of the user.
    """
    uid = update.effective_user.id
    await ensure_user(uid)

    job_id = None
    if context.args:
        try:
            job_id = int(context.args[0])
        except ValueError:
            return await update.message.reply_text("❌ job_id должен быть числом.")

    async with DB_POOL.acquire() as con:
        if job_id is None:
            row = await con.fetchrow(
                """select id, status from jobs
                     where user_id=$1 and status in ('queued','running')
                     order by id desc
                     limit 1""",
                int(uid)
            )
        else:
            row = await con.fetchrow(
                "select id, user_id, status from jobs where id=$1",
                int(job_id)
            )
            if row and int(row["user_id"]) != int(uid) and uid != ADMIN_ID:
                return await update.message.reply_text("❌ Можно отменять только свои задачи.")
        if not row:
            return await update.message.reply_text("Нет активных задач для отмены.")

        jid = int(row["id"])
        st = row["status"]

        if st == "queued":
            await con.execute(
                "update jobs set status='canceled', cancel_requested=true, finished_at=now() where id=$1",
                jid
            )
            # if a worker had created an event, set it too (harmless)
            ev = CANCEL_EVENTS.get(jid)
            if ev:
                ev.set()
            return await update.message.reply_text(f"✅ Задача {jid} отменена (в очереди).")

        # running
        await con.execute(
            "update jobs set cancel_requested=true where id=$1",
            jid
        )
        ev = CANCEL_EVENTS.get(jid)
        if ev:
            ev.set()
            return await update.message.reply_text(f"🛑 Запрошена отмена задачи {jid}. Останавливаю скачивание…")
        return await update.message.reply_text(f"🛑 Запрошена отмена задачи {jid}. Если уже почти скачалось — остановка может занять немного времени.")


async def on_cancel_button(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    uid = query.from_user.id
    await ensure_user(uid)

    m = re.match(r"cancel_(\d+)", query.data or "")
    if not m:
        return
    jid = int(m.group(1))

    async with DB_POOL.acquire() as con:
        row = await con.fetchrow("select id, user_id, status from jobs where id=$1", jid)
        if not row:
            return await query.message.reply_text("Задача не найдена.")
        if int(row["user_id"]) != int(uid) and uid != ADMIN_ID:
            return await query.message.reply_text("❌ Можно отменять только свои задачи.")
        st = row["status"]
        if st == "queued":
            await con.execute("update jobs set status='canceled', cancel_requested=true, finished_at=now() where id=$1", jid)
            ev = CANCEL_EVENTS.get(jid)
            if ev:
                ev.set()
            return await query.message.reply_text(f"✅ Задача {jid} отменена.")
        if st == "running":
            await con.execute("update jobs set cancel_requested=true where id=$1", jid)
            ev = CANCEL_EVENTS.get(jid)
            if ev:
                ev.set()
            return await query.message.reply_text(f"🛑 Отмена задачи {jid} запрошена.")
        return await query.message.reply_text(f"Задача {jid} уже {st}.")

async def run_jobs_cleanup_once() -> tuple[int, int]:
    """Run cleanup immediately. Returns (deleted_done_canceled, deleted_failed)."""
    async with DB_POOL.acquire() as con:
        d1 = await con.execute(
            """delete from jobs
                 where status in ('done','canceled')
                   and finished_at is not null
                   and finished_at < now() - ($1::int * interval '1 day')""",
            int(JOBS_TTL_DAYS)
        )
        d2 = await con.execute(
            """delete from jobs
                 where status = 'failed'
                   and finished_at is not null
                   and finished_at < now() - ($1::int * interval '1 day')""",
            int(FAILED_TTL_DAYS)
        )
    # asyncpg returns strings like "DELETE 10"
    def _n(s: str) -> int:
        try:
            return int(s.split()[-1])
        except Exception:
            return 0
    return _n(d1), _n(d2)


async def cleanup_jobs(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Admin: run jobs cleanup manually."""
    if update.effective_user.id != ADMIN_ID:
        return await update.message.reply_text("❌ У вас нет прав.")
    d_done, d_failed = await run_jobs_cleanup_once()
    await update.message.reply_text(
        f"🧹 Очистка завершена.\n"
        f"Удалено done/canceled: {d_done} (старше {JOBS_TTL_DAYS}d)\n"
        f"Удалено failed: {d_failed} (старше {FAILED_TTL_DAYS}d)"
    )


async def bump(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Admin: move a queued job to the front by increasing its priority above current max."""
    if update.effective_user.id != ADMIN_ID:
        return await update.message.reply_text("❌ У вас нет прав.")
    if not context.args:
        return await update.message.reply_text("Использование: /bump <job_id>")
    try:
        jid = int(context.args[0])
    except ValueError:
        return await update.message.reply_text("❌ job_id должен быть числом.")
    async with DB_POOL.acquire() as con:
        row = await con.fetchrow("select status from jobs where id=$1", jid)
        if not row:
            return await update.message.reply_text("Задача не найдена.")
        if row["status"] != "queued":
            return await update.message.reply_text("Можно поднимать только задачи со статусом queued.")
        mx = int(await con.fetchval("select coalesce(max(priority),0) from jobs where status='queued'") or 0)
        await con.execute("update jobs set priority=$2 where id=$1", jid, mx + 1)
    WORK_AVAILABLE.set()
    await update.message.reply_text(f"✅ Задача {jid} поднята в начало очереди.")


async def prio(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Admin: set explicit priority for a queued job. Usage: /prio <job_id> <priority>"""
    if update.effective_user.id != ADMIN_ID:
        return await update.message.reply_text("❌ У вас нет прав.")
    if len(context.args) < 2:
        return await update.message.reply_text("Использование: /prio <job_id> <priority>")
    try:
        jid = int(context.args[0])
        p = int(context.args[1])
    except ValueError:
        return await update.message.reply_text("❌ job_id и priority должны быть числами.")
    async with DB_POOL.acquire() as con:
        row = await con.fetchrow("select status from jobs where id=$1", jid)
        if not row:
            return await update.message.reply_text("Задача не найдена.")
        if row["status"] != "queued":
            return await update.message.reply_text("Менять приоритет можно только для queued.")
        await con.execute("update jobs set priority=$2 where id=$1", jid, p)
    WORK_AVAILABLE.set()
    await update.message.reply_text(f"✅ Приоритет задачи {jid} установлен: {p}")



def get_format_size_bytes(fmt: dict, duration: int | None = None) -> tuple[int, bool]:
    """Return (size_bytes, is_approx). yt-dlp часто не даёт filesize.
    Пытаемся: filesize -> filesize_approx -> оценка по bitrate * duration.
    """
    try:
        size = fmt.get("filesize")
        if size:
            return int(size), False
        size = fmt.get("filesize_approx")
        if size:
            return int(size), True
        dur = int(duration or 0)
        if dur <= 0:
            dur = int(fmt.get("duration") or 0)
        tbr = fmt.get("tbr") or fmt.get("vbr") or fmt.get("abr")
        if tbr and dur > 0:
            # tbr is in Kbit/s
            return int(float(tbr) * 1000 / 8 * dur), True
    except Exception:
        pass
    return 0, True

async def debug(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not context.args:
        return await update.message.reply_text("Использование: /debug <URL>")
    url = context.args[0]
    try:
        with yt_dlp.YoutubeDL({'quiet': True, 'skip_download': True, 'noplaylist': True}) as ydl:
            info = ydl.extract_info(url, download=False)
        lines = [
            f"{fmt['format_id']} — {fmt.get('height')}p — {round(((fmt.get('filesize') or fmt.get('filesize_approx') or 0)/1024/1024),1)}MB"
            for fmt in info.get('formats', [])[:20]
        ]
        await update.message.reply_text("\n".join(lines))
    except Exception:
        logger.exception("Ошибка debug")
        await update.message.reply_text("❌ Ошибка при выполнении debug.")


# ---------------
# Message flow: preview + buttons (as in original)
# ---------------
async def on_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    asyncio.create_task(process_message(update, context))


async def process_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    msg = update.message
    uid = msg.from_user.id
    await ensure_user(uid)

    # access gate
    if not await ensure_access_or_prompt(update, context):
        return

    # cooldown & user queue limit (anti-spam)
    now = time.time()
    last = USER_COOLDOWN.get(uid, 0.0)
    if now - last < COOLDOWN_SECONDS:
        return await msg.reply_text("🕒 Слишком часто. Подожди пару секунд.", reply_to_message_id=msg.message_id)
    USER_COOLDOWN[uid] = now

    active = await user_active_jobs_count(uid)
    if active >= MAX_QUEUE_PER_USER:
        return await msg.reply_text(
            f"📥 У тебя уже {active} задач(и) в очереди/в работе. Лимит: {MAX_QUEUE_PER_USER}.",
            reply_to_message_id=msg.message_id
        )

    url = msg.text.strip()
    url = normalize_youtube_url(url)
    if 'youtu' not in url:
        return await msg.reply_text('Это не ссылка YouTube.', reply_to_message_id=msg.message_id)

    orig_id = msg.message_id
    try:
        info = await asyncio.to_thread(
            lambda: yt_dlp.YoutubeDL({'quiet': True, 'skip_download': True, 'noplaylist': True}).extract_info(url, download=False)
        )
    except Exception:
        logger.exception("Ошибка получения информации")
        return await msg.reply_text('❌ Не удалось получить информацию.', reply_to_message_id=orig_id)

    is_shorts = 'shorts/' in url
    title = info.get('title', 'N/A')
    uploader = info.get('uploader', 'N/A')
    raw_date = info.get('upload_date')
    try:
        pub_date = datetime.strptime(raw_date, '%Y%m%d').strftime('%d.%m.%Y') if raw_date else 'N/A'
    except Exception:
        pub_date = raw_date or 'N/A'
    duration = info.get('duration', 0)
    h, rem = divmod(duration, 3600)
    m, s = divmod(rem, 60)
    duration_str = f"{h:02}:{m:02}:{s:02}"

    me = await context.bot.get_me()
    bot_link = f"https://t.me/{me.username}"

    caption = (
        f"🎬 <b>Название:</b> {title}\n"
        f"👤 <b>Автор:</b> {uploader}\n"
        f"📅 <b>Дата:</b> {pub_date}\n"
        f"⏱ <b>Длительность:</b> {duration_str}\n\n"
        f"🔗 <b>Бот:</b> {bot_link}"
    )

    buttons = []
    formats_map = {}
    cached_fmts = await cache_get_fmts(url)

    if is_shorts:
        # single button, treat as best
        buttons.append([InlineKeyboardButton('⏩ Скачать Shorts', callback_data='auto')])
        formats_map['auto'] = 'best'
    else:
        res_map = {}
        for fmt in info.get('formats', []):
            if fmt.get('vcodec') == 'none':
                continue
            height = fmt.get('height')
            size, approx = get_format_size_bytes(fmt, duration)
            if height:
                prev = res_map.get(height)
                if (not prev) or (size and size > prev['size']) or (prev['size'] == 0 and size > 0):
                    res_map[height] = {'format_id': fmt['format_id'], 'size': size, 'approx': approx}

        for height in sorted(res_map.keys(), reverse=True):
            data = res_map[height]
            fid, size, approx = data['format_id'], data['size'], data.get('approx', True)
            if size <= 0:
                label_size = " ?MB"
                mb = 0.0
            else:
                mb = round(size/1024/1024, 1)
                label_size = f" ~{mb}MB" if approx else f" {mb}MB"

            if mb > 2000:
                cache_mark = " 📦" if fid in cached_fmts else ""
                buttons.append([InlineKeyboardButton(f"{height}p —{label_size}{cache_mark} 🚫", callback_data=f"too_big_{height}")])
            else:
                cache_mark = " 📦" if fid in cached_fmts else ""
                buttons.append([InlineKeyboardButton(f"{height}p —{label_size}{cache_mark}", callback_data=str(height))])
                formats_map[str(height)] = fid

    reply_markup = InlineKeyboardMarkup(buttons)

    sent = None
    if thumb_url := info.get('thumbnail'):
        sent = await msg.reply_photo(thumb_url, caption=caption, parse_mode='HTML',
                              reply_markup=reply_markup, reply_to_message_id=orig_id)
    else:
        sent = await msg.reply_text(caption, parse_mode='HTML',
                             reply_markup=reply_markup, reply_to_message_id=orig_id)

    # Store only lightweight info in user_data for callback
    context.user_data.update({
        'video_info': {'title': title, 'uploader': uploader, 'pub_date': pub_date,
                       'duration_str': duration_str, 'bot_link': bot_link},
        'video_url': url,
        'formats': formats_map,
        'duration': duration,
        'orig_message_id': orig_id,
        'progress_message_id': sent.message_id if sent else None,
        'progress_has_photo': bool(getattr(sent, 'photo', None)) if sent else False
    })


# ---------------
# Callback: quality chosen -> create job -> enqueue
# ---------------
async def on_quality_chosen(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.callback_query and update.callback_query.data == "check_access":
        return await on_inline_access_check(update, context)
    if update.callback_query and (update.callback_query.data or '').startswith('cancel_'):
        return await on_cancel_button(update, context)
    asyncio.create_task(process_quality(update, context))


async def on_inline_access_check(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    uid = query.from_user.id
    await ensure_user(uid)
    if (not await whitelist_is_enabled()) or await is_user_whitelisted(uid) or await is_user_subscribed_to_required_channel(context, uid):
        try:
            await query.message.reply_text("✅ Доступ подтверждён. Можешь отправлять ссылку на YouTube.")
        except Exception:
            pass
    else:
        try:
            await query.message.reply_text("⛔️ Доступ пока не открыт. Подпишись на канал и нажми /check, или попроси админа добавить тебя в whitelist.")
        except Exception:
            pass


async def process_quality(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    data = context.user_data

    if query.data.startswith('too_big_'):
        return await query.answer('❌ Превышен лимит Telegram.', show_alert=True)

    await query.answer()

    uid = query.from_user.id
    await ensure_user(uid)

    if not await ensure_access_or_prompt(update, context):
        return

    # enforce per-user queue limits at selection time too
    active = await user_active_jobs_count(uid)
    if active >= MAX_QUEUE_PER_USER:
        return await query.message.reply_text(f"📥 У тебя уже {active} задач(и) в очереди/в работе. Лимит: {MAX_QUEUE_PER_USER}.")

    url = data['video_url']
    fmt = data['formats'][query.data]
    duration = int(data.get('duration') or 0)
    orig_id = data.get('orig_message_id')
    video_info = data.get('video_info') or {}

    job_id = await create_job(
        user_id=uid,
        chat_id=query.message.chat_id,
        reply_to_message_id=orig_id,
        progress_message_id=data.get('progress_message_id') or query.message.message_id,
        progress_has_photo=bool(data.get('progress_has_photo') or getattr(query.message, 'photo', None)),
        url=url,
        fmt=fmt,
        label=query.data,
        duration=duration,
        video_info=video_info
    )

    WORK_AVAILABLE.set()

    # show queue position / count
    pos, total_q, running = await queue_position(job_id)
    u_pos, u_total = await user_job_position(job_id, uid)
    qn = await user_active_jobs_count(uid)
    try:
        if getattr(query.message, 'photo', None):
            await query.edit_message_caption(f"📥 В очереди: #{pos} из {total_q} (в работе: {running}), а вы #{u_pos} из {u_total} у себя. Подготовка…", reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton('❌ Отменить', callback_data=f'cancel_{job_id}')]]))
        else:
            await query.edit_message_text(f"📥 В очереди: #{pos} из {total_q} (в работе: {running}), а вы #{u_pos} из {u_total} у себя. Подготовка…", reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton('❌ Отменить', callback_data=f'cancel_{job_id}')]]))
    except Exception:
        pass


# ---------------
# Worker logic
# ---------------
async def worker_loop(worker_id: int, app):
    logger.info("Worker %d started", worker_id)
    while not SHUTDOWN_EVENT.is_set():
        try:
            # Wait until there might be work (event) or poll periodically
            try:
                await asyncio.wait_for(WORK_AVAILABLE.wait(), timeout=2.0)
            except asyncio.TimeoutError:
                pass
            WORK_AVAILABLE.clear()

            if SHUTDOWN_EVENT.is_set():
                break

            job = await claim_next_job()
            if not job:
                continue

            job_id = int(job["id"])
            RUNNING_JOBS.add(job_id)
            try:
                await handle_job(job, app)
                # handle_job may set status canceled/failed; only mark done if still running
                j2 = await fetch_job(job_id)
                if j2 and j2.get("status") == "running":
                    await mark_job_done(job_id)
            except Exception as e:
                logger.exception("Worker %d job %s error", worker_id, job_id)
                # If not already canceled, mark failed
                j2 = await fetch_job(job_id)
                if j2 and j2.get("status") == "running":
                    await mark_job_failed(job_id, str(e))
            finally:
                RUNNING_JOBS.discard(job_id)
        except Exception:
            logger.exception("Worker %d loop error", worker_id)
            await asyncio.sleep(1.0)

    logger.info("Worker %d stopped (shutdown)", worker_id)



async def handle_job(job: dict, app):
    job_id = int(job["id"])
    user_id = int(job["user_id"])
    chat_id = int(job["chat_id"])
    progress_message_id = int(job.get("progress_message_id") or 0)
    has_photo = bool(job.get("progress_has_photo"))
    reply_to = job.get("reply_to_message_id")
    url = job["url"]
    fmt = job["fmt"]
    label = job.get("label") or ""
    duration = int(job.get("duration") or 0)

    video_info = {
        "title": job.get("title") or "N/A",
        "uploader": job.get("uploader") or "N/A",
        "pub_date": job.get("pub_date") or "N/A",
        "duration_str": job.get("duration_str") or "00:00:00",
        "bot_link": job.get("bot_link") or "",
    }

    # 1) cache
    cache_meta = await cache_get_meta(url, fmt)
    cached_file_id = (cache_meta or {}).get("file_id")
    if cached_file_id:
        cached_info = dict(video_info)
        if cache_meta:
            if cache_meta.get("title"):
                cached_info["title"] = cache_meta.get("title")
            if cache_meta.get("uploader"):
                cached_info["uploader"] = cache_meta.get("uploader")
        cached_res = (cache_meta or {}).get("resolution") or "N/A"
        caption = "📦 <b>Из кэша</b>\n" + build_caption(cached_info, resolution=cached_res)
        payload = {
            'chat_id': str(chat_id),
            'video': cached_file_id,
            'caption': caption,
            'parse_mode': 'HTML',
        }
        if reply_to is not None:
            payload['reply_to_message_id'] = str(reply_to)
        requests.post(f"{API_BASE_URL}{BOT_TOKEN}/sendVideo", data=payload)
        try:
            await app.bot.delete_message(chat_id=chat_id, message_id=progress_message_id)
        except Exception:
            pass
        async with DB_POOL.acquire() as con:
            await con.execute("insert into downloads(user_id,url,fmt,status) values($1,$2,$3,'done')", user_id, url, fmt)
        CANCEL_EVENTS.pop(job_id, None)
        return

    # 2) download with progress
    loop = asyncio.get_running_loop()
    cancel_ev = asyncio.Event()
    CANCEL_EVENTS[job_id] = cancel_ev
    hook = make_progress_hook(loop, app, chat_id, progress_message_id, has_photo, label)
    def _cancel_guard(d):
        if cancel_ev.is_set():
            raise RuntimeError('cancelled')
    ydl_hooks = [hook, _cancel_guard]

    ydl_format = "bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]/best" if fmt == 'best' else fmt + "+bestaudio/best"
    raw_path = os.path.join(tmp_dir, f"{chat_id}_{job_id}_{label}_video.mp4")
    thumb_path = raw_path.replace('_video.mp4', '_thumb.jpg')

    # initial status
    try:
        if has_photo:
            await app.bot.edit_message_caption(chat_id=chat_id, message_id=progress_message_id, caption=f"⏬ Скачиваю {label}...")
        else:
            await app.bot.edit_message_text(chat_id=chat_id, message_id=progress_message_id, text=f"⏬ Скачиваю {label}...")
    except Exception:
        pass

    try:
        await asyncio.to_thread(lambda: yt_dlp.YoutubeDL({
            'format': ydl_format,
            'merge_output_format': 'mp4',
            'noplaylist': True,
            'outtmpl': raw_path,
            'quiet': True,
            'noprogress': True,
            'progress_hooks': ydl_hooks,
            # speed tweaks
            'concurrent_fragment_downloads': 8,
            'retries': 3,
            'fragment_retries': 3,
        }).download([url]))
    except Exception as e:
        # cancel requested?
        if cancel_ev.is_set() or str(e) == 'cancelled':
            await mark_job_canceled(job_id)
            try:
                await app.bot.edit_message_text(chat_id=chat_id, message_id=progress_message_id, text='✅ Отменено.')
            except Exception:
                try:
                    await app.bot.edit_message_caption(chat_id=chat_id, message_id=progress_message_id, caption='✅ Отменено.')
                except Exception:
                    pass
            try:
                await app.bot.delete_message(chat_id=chat_id, message_id=progress_message_id)
            except Exception:
                pass
            async with DB_POOL.acquire() as con:
                await con.execute("insert into downloads(user_id,url,fmt,status) values($1,$2,$3,'failed')", user_id, url, fmt)
            CANCEL_EVENTS.pop(job_id, None)
            return
        try:
            if has_photo:
                await app.bot.edit_message_caption(chat_id=chat_id, message_id=progress_message_id, caption='❌ Ошибка скачивания.')
            else:
                await app.bot.edit_message_text(chat_id=chat_id, message_id=progress_message_id, text='❌ Ошибка скачивания.')
        except Exception:
            pass
        async with DB_POOL.acquire() as con:
            await con.execute("insert into downloads(user_id,url,fmt,status) values($1,$2,$3,'failed')", user_id, url, fmt)
        CANCEL_EVENTS.pop(job_id, None)
        raise

    # 3) thumbnail
    try:
        if has_photo:
            await app.bot.edit_message_caption(chat_id=chat_id, message_id=progress_message_id, caption='🖼 Генерирую thumbnail...')
        else:
            await app.bot.edit_message_text(chat_id=chat_id, message_id=progress_message_id, text='🖼 Генерирую thumbnail...')
    except Exception:
        pass

    try:
        subprocess.check_call(['ffmpeg','-y','-i',raw_path,'-ss','00:00:01','-vframes','1','-vf','scale=320:-1','-update','1',thumb_path])
    except Exception:
        thumb_path = None

    width, height = get_video_dimensions(raw_path)
    resolution_str = f"{width}×{height}"
    caption = build_caption(video_info, resolution=resolution_str)

    # 4) send
    try:
        if has_photo:
            await app.bot.edit_message_caption(chat_id=chat_id, message_id=progress_message_id, caption='⏫ Отправляю видео...')
        else:
            await app.bot.edit_message_text(chat_id=chat_id, message_id=progress_message_id, text='⏫ Отправляю видео...')
    except Exception:
        pass

    files = {'video': open(raw_path, 'rb')}
    if thumb_path and os.path.exists(thumb_path):
        files['thumb'] = open(thumb_path, 'rb')

    try:
        payload = {
            'chat_id': str(chat_id),
            'duration': str(duration),
            'width': str(width),
            'height': str(height),
            'supports_streaming': 'true',
            'caption': caption,
            'parse_mode': 'HTML',
        }
        if reply_to is not None:
            payload['reply_to_message_id'] = str(reply_to)
        resp = requests.post(f"{API_BASE_URL}{BOT_TOKEN}/sendVideo", data=payload, files=files)
    finally:
        for f in files.values():
            try:
                f.close()
            except Exception:
                pass

    # cleanup
    try:
        os.remove(raw_path)
    except Exception:
        pass
    if thumb_path and os.path.exists(thumb_path):
        try:
            os.remove(thumb_path)
        except Exception:
            pass

    if resp.ok and resp.json().get('ok'):
        telegram_file_id = resp.json()['result']['video']['file_id']
        await cache_upsert(
            url, fmt, telegram_file_id,
            title=video_info.get('title'),
            uploader=video_info.get('uploader'),
            duration=duration,
            resolution=resolution_str
        )
        try:
            await app.bot.delete_message(chat_id=chat_id, message_id=progress_message_id)
        except Exception:
            pass
        async with DB_POOL.acquire() as con:
            await con.execute("insert into downloads(user_id,url,fmt,status) values($1,$2,$3,'done')", user_id, url, fmt)
        CANCEL_EVENTS.pop(job_id, None)
    else:
        err = resp.text
        logger.error('sendVideo HTTP error: %s', err)
        async with DB_POOL.acquire() as con:
            await con.execute("insert into downloads(user_id,url,fmt,status) values($1,$2,$3,'failed')", user_id, url, fmt)
        CANCEL_EVENTS.pop(job_id, None)
        raise RuntimeError(err)


# ---------------
# Startup
# ---------------
async def post_init(app):
    await init_db()
    # background cleanup
    asyncio.create_task(cache_cleanup_loop())
    asyncio.create_task(jobs_cleanup_loop())
    # requeue pending jobs
    await requeue_incomplete_jobs()
    # start workers
    for i in range(WORKERS):
        asyncio.create_task(worker_loop(i + 1, app))

async def post_shutdown(app):
    """Graceful shutdown:
    - stop workers from claiming new jobs
    - request cancel for currently running jobs (best-effort)
    - close DB pool
    """
    try:
        SHUTDOWN_EVENT.set()
        WORK_AVAILABLE.set()  # wake workers

        # Best-effort: cancel running jobs
        running_ids = list(RUNNING_JOBS)
        if running_ids:
            async with DB_POOL.acquire() as con:
                await con.execute(
                    "update jobs set cancel_requested=true where id = any($1::bigint[]) and status='running'",
                    running_ids
                )
            for jid in running_ids:
                ev = CANCEL_EVENTS.get(int(jid))
                if ev:
                    ev.set()

        # Give ongoing tasks a moment to react (download hooks) before DB closes
        await asyncio.sleep(0.5)
    finally:
        try:
            if DB_POOL:
                await DB_POOL.close()
        except Exception:
            pass



if __name__ == '__main__':
    request = HTTPXRequest(read_timeout=3600)
    app = (
        ApplicationBuilder()
        .token(BOT_TOKEN)
        .base_url(API_BASE_URL)
        .local_mode(True)
        .request(request)
        .post_init(post_init)
        .post_shutdown(post_shutdown)
        .build()
    )

    app.add_handler(CommandHandler('start', start))
    app.add_handler(CommandHandler('admin', admin))
    app.add_handler(CommandHandler('check', check))
    app.add_handler(CommandHandler('stats', stats))
    app.add_handler(CommandHandler('queue', queue_cmd))
    app.add_handler(CommandHandler('myqueue', myqueue))
    app.add_handler(CommandHandler('cancel', cancel))
    app.add_handler(CommandHandler('cleanup_jobs', cleanup_jobs))
    app.add_handler(CommandHandler('bump', bump))
    app.add_handler(CommandHandler('prio', prio))
    app.add_handler(CommandHandler('broadcast', broadcast))
    app.add_handler(CommandHandler('debug', debug))

    # Admin whitelist controls
    app.add_handler(CommandHandler('wl_on', wl_on))
    app.add_handler(CommandHandler('wl_off', wl_off))
    app.add_handler(CommandHandler('wl_status', wl_status))
    app.add_handler(CommandHandler('wl_add', wl_add))
    app.add_handler(CommandHandler('wl_del', wl_del))
    app.add_handler(CommandHandler('wl_list', wl_list))

    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, admin_input_router), group=0)
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, on_message), group=1)
    app.add_handler(CallbackQueryHandler(admin_callback, pattern=r'^admin:'))
    app.add_handler(CallbackQueryHandler(on_quality_chosen))

    logger.info(Fore.GREEN + f"Бот запущен (Postgres + queue), WORKERS={WORKERS}" + Style.RESET_ALL)
    try:
        app.run_polling()
    except (KeyboardInterrupt, SystemExit):
        pass
    finally:
        logger.info(Fore.RED + "Бот остановлен" + Style.RESET_ALL)
