# dlbot — установка на Ubuntu (VDS)

## Требования
- Ubuntu 20.04/22.04/24.04
- Домен/SSL не требуется (бот работает через Telegram)
- Открытый порт **8081** (если хочешь дергать локальный Bot API снаружи — обычно не нужно)

## 1) Установка Docker
```bash
apt update
apt install -y ca-certificates curl gnupg
install -m 0755 -d /etc/apt/keyrings
curl -fsSL https://download.docker.com/linux/ubuntu/gpg | gpg --dearmor -o /etc/apt/keyrings/docker.gpg
chmod a+r /etc/apt/keyrings/docker.gpg
echo   "deb [arch=$(dpkg --print-architecture) signed-by=/etc/apt/keyrings/docker.gpg] https://download.docker.com/linux/ubuntu   $(. /etc/os-release && echo $VERSION_CODENAME) stable"   > /etc/apt/sources.list.d/docker.list
apt update
apt install -y docker-ce docker-ce-cli containerd.io docker-buildx-plugin docker-compose-plugin
```

## 2) Развернуть бота
Рекомендуемый путь: `/root/dlbot`

```bash
mkdir -p /root/dlbot
cd /root/dlbot
# распакуй архив сюда (scp / wget / вручную)
```

## 3) Настроить .env
```bash
cp .env.example .env
nano .env
```

Обязательные поля:
- `BOT_TOKEN` — токен бота от @BotFather
- `ADMIN_ID` — твой Telegram user id
- `TELEGRAM_API_ID` и `TELEGRAM_API_HASH` — нужны для локального Bot API (получить: https://core.telegram.org/api/obtaining_api_id)

## 4) Запуск
```bash
cd /root/dlbot
docker compose -p dlbot up -d --build
docker compose -p dlbot ps
```

Логи:
```bash
docker logs -f dlbot-bot-1
docker logs -f dlbot-tg-bot-api-1
```

## 5) Обновление
1) заменить файлы (например `bot.py`)
2) пересобрать:
```bash
docker compose -p dlbot up -d --build bot
```

## 6) Полезные команды
Остановить:
```bash
docker compose -p dlbot down
```

Перезапуск:
```bash
docker compose -p dlbot restart
```

Проверить health:
```bash
docker compose -p dlbot ps
docker inspect --format '{{range .State.Health.Log}}{{println .End " exit=" .ExitCode " out=" .Output}}{{end}}' dlbot-tg-bot-api-1 | tail -n 10
```
