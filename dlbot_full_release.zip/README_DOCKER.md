# ytbot — Docker + docker-compose (Postgres + Local Telegram Bot API)

Этот комплект поднимает:
- Postgres
- локальный Telegram Bot API server (tdlib/telegram-bot-api) — нужен, чтобы отправлять файлы >50MB (до 2GB)
- сам бот

## 1) Подготовка
1. Скопируй `.env.example` в `.env` и заполни:
   - `BOT_TOKEN`
   - `ADMIN_ID`
   - `TELEGRAM_API_ID` и `TELEGRAM_API_HASH` (получить: https://core.telegram.org/api/obtaining_api_id)

## 2) Запуск
```bash
docker compose up -d --build
```

Логи:
```bash
docker compose logs -f bot
docker compose logs -f tg-bot-api
```

## 3) Важно про большие файлы (до 2GB)
Бот настроен на работу через локальный Bot API:
- `API_BASE_URL=http://tg-bot-api:8081/bot`
- в коде используется `local_mode(True)` для python-telegram-bot

Это позволяет загружать большие видео через ваш Bot API сервер.

## 4) Данные и volumes
- `pgdata` — база Postgres
- `tgapidata` — кеш/файлы Bot API сервера (ускоряет повторные аплоады)

## 5) Обновление
```bash
docker compose pull tg-bot-api
docker compose up -d --build
```


## Healthchecks + автоперезапуск
- Для postgres, tg-bot-api и bot добавлены healthcheck'и.
- bot запускается только после того, как postgres и tg-bot-api стали healthy.
- restart policy: `unless-stopped` (контейнеры перезапускаются при падении).

## stop_grace_period + rotation логов
В `docker-compose.yml` добавлено:
- `stop_grace_period: 5m` для `bot` — даём время закончить текущую загрузку/отправку перед принудительным убийством.
- `stop_grace_period: 30s` для postgres и tg-bot-api.
- rotation логов через `json-file`:
  - `max-size: 10m`
  - `max-file: 5`

Если хочешь другие значения (например 50m/3 файла) — скажи.
